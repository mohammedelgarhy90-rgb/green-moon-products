Green Moon CMS API — Menu Buttons Fix

This update fixes the "الأزرار الحالية — Not found" error in the admin menu manager.
It adds the menu_items table, default menu entries, GET/POST/PUT/DELETE /api/admin/menu endpoints,
and returns active menu items from /api/store.

Upload worker.js to the GitHub repository connected to green-moon-products and deploy.
Do not upload this worker.js to the customer static catalog site.
