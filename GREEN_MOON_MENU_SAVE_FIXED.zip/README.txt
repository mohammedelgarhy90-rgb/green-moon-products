Green Moon - Menu Save Fix
Replace worker.js in the GitHub repository connected to green-moon-products.
Fixes /api/admin/menu GET/POST/PUT/DELETE so the editable menu buttons save correctly.
Keeps the existing menu_items schema and data.
