Green Moon - Category Products Update
Upload worker.js to the GitHub repository connected to green-moon-products.
Do not upload this to the catalog static site.

This update:
- shows real products inside database categories on the customer site
- category cards show a product image and product count
- clicking a category opens its products
- product editing can assign the product to a real category
- new products resolve categorySlug into category_id
- adds admin category API endpoints
