GREEN MOON CATALOG — WELCOME FIX

Replace worker.js in the green-moon-products GitHub repository with this file and commit to main.
Cloudflare Workers Builds is connected to the repository.

Fix:
- Enter Green Moon works even if the main JS/audio initializer fails.
- Welcome overlay hides immediately on click.
- Audio playback is best-effort and never blocks entering the site.
- Existing product/admin/API functionality is preserved.
