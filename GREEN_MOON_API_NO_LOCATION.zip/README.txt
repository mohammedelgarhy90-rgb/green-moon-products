GREEN MOON — API / ADMIN FINAL AUDIT FIX

Deploy worker.js to the GitHub/Cloudflare Worker connected to:
green-moon-products.greenmoon-eg.workers.dev

This version adds/fixes:
- Public GET /api/products for the customer catalog.
- Public GET /api/products/:id for product details.
- Admin GET /api/admin/products.
- Admin order list + status updates.
- Admin category CRUD.
- Product create/edit now resolves real category_id and preserves sections.
- Customer orders are stored in D1.
- Product detail routing support in the included admin/customer demo code.

Required bindings/secrets remain the same (D1 DB, ADMIN_TOKEN, and OPENAI_API_KEY if used).
