Green Moon - Unified Sync Worker

هذا الملف هو Worker موحد لإدارة المتجر.
- نفس قاعدة D1: green-moon-store عبر binding DB.
- /admin و /admin/ يفتحان لوحة التحكم مباشرة بدون Welcome overlay.
- /api/store هو مصدر البيانات العام للموقع.
- /api/products/:id متاح لصفحات المنتجات.
- تعديلات وإضافة وحذف المنتجات من لوحة التحكم تُحفظ في D1، وموقع العملاء يقرأ نفس البيانات.
- لا توجد أي وظائف GPS أو تحديد موقع.

ملف النشر: worker.js
