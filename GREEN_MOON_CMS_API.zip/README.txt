Green Moon API Worker - CMS update
Replace the worker.js in the GitHub repository connected to green-moon-products with this worker.js.
The worker keeps existing product/category/offer/music functionality and adds CMS content + articles stored in D1.
New admin endpoints: /api/admin/cms, /api/admin/cms/content, /api/admin/articles.
Customer /api/store now returns articles and CMS content.
